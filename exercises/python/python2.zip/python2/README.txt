Link to Rosalind:

http://rosalind.info/classes/enroll/fcdc164b3c/
