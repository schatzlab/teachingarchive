## URP Bootcamp Exercise 4
################################################################################
## In this exericse you will use a brute force approach to find exact matches
## of a query string in a genome string


genome = "TGATTACAGATTACCAAATTTCCCGATTACA"
query = "GATTACA"

   
    
    
## Challenge questions: 
###############################################################################
## 1. Implement Brute force search
## 2. How would you modify this to find matches within hamming distance D?
## 3. How would you scan the entire ecoli genome?
## 4. Pick 100 random kmers and compute their frequency in the genome?
## 5. Use the suffix array to compute the matches (hard)
## 6. Use the suffix array to quickly compute approximate matches
