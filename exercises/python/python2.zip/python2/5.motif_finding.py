## URP Bootcamp Exercise 5
################################################################################
## In this exercise you will find a DNA binding motif from the DNA60IFX challenge
## Download the sequences from: http://genomebiology.com/about/update/DNA60_STEPONE

## dictionaries are like arrays, but can be accessed by a string
kmers = {}
kmers["GATTACA"] = 10
kmers["ACGTGCA"] = 50
kmers["TATATAT"] = 100

print "kmers are: " + str(kmers)
print "kmers[GATTACA] is: " + str(kmers["GATTACA"])

kmer="GATTACA"
print "kmers[kmer] is: " + str(kmers[kmer])

kmers[kmer] += 1

print "kmers are: " + str(kmers)
print "kmers[GATTACA] is: " + str(kmers["GATTACA"])

for kmer in kmers.keys():
    cnt = kmers[kmer]
    print "%s: %d" % (kmer, cnt)




## Scan the sequences and count the number of times each kmer occurs
###############################################################################

# reset the kmers table
kmers = {}

## define the kmer length
k = 7

linenum = 0
numsequences = 0
numbases = 0
verbose = False

# open the file with the sequences
f = open("motif_finding.fa")

# read each line of the file
for line in f:
    linenum += 1
    
    # chop of the newline at the end
    line = line.rstrip()

    if (line[0] == ">"):
        if (verbose): print "Processing sequence: " + line
        numsequences += 1
        
    else:
        if (verbose): print line;
        numbases += len(line)
        
        ## Extract the kmers and update the dictionary
        for i in xrange(len(line)-k+1):
            kmer = line[i : i+k]
            if (verbose): print "  %d: %s" % (i, kmer)
            kmers[kmer] = kmers.get(kmer, 0) + 1

print "Processed %d lines, %d sequences, %d total bases" % (linenum, numsequences, numbases)
print "There were %d distinct kmers in the data" % len(kmers)



## Now scan the dictionary to find the most frequent kmer
###############################################################################

maxkmer = ""
maxkmercnt = 0

for kmer in kmers.keys():
    cnt = kmers[kmer]
    if (cnt > maxkmercnt):
        maxkmer = kmer
        maxkmercnt = cnt
        
print "The most frequent kmer was %s and occured %d times" % (maxkmer, maxkmercnt)



## Find the top 10 most frequent kmers
################################################################################

import operator
sorted_kmers = sorted(kmers.iteritems(), key=operator.itemgetter(1), reverse=True)

for x in xrange(10):
    k,v = sorted_kmers[x]
    print "%d: %s %d" % (x, k, v)
    



## Challenge questions
################################################################################

## 1. How many kmers occur more than 10 or 100 times?
## 2. How would you compute the mean and standard deviation of kmer frequency