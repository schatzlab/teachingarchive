## URP Bootcamp Exercise 5
################################################################################
## In this exericse you will use a brute force approach to find exact matches
## of a query string in a genome string


genome = "TGATTACAGATTACCAAATTTCCCGATTACA"
query  = "GATTACA"

   
    
    
## Challenge questions: 
###############################################################################
## 1. Implement Brute force search to find every place the query occurs in the genome

