## URP Bootcamp Exercise 2
################################################################################
## In this exericse you will learn about using for loops to repeat instructions
## multiple times


name="Mike"
repeat=5


## Lets say hello repeat times with a for loop
## xrange iterates between 0 and repeat-1
## Note: whitespace is required to show the body of a loop

hello_count = 0 

for x in xrange(repeat):
    print "Iteration %d: Hello, %s" % (x, name)
    hello_count += 1
    
print
print "I said hello %d times" % (hello_count)

        
                
## Loops can also be nested (summing every value in a matrix)
###############################################################################

hello_count = 0
for x in xrange(repeat):
    print "x is now %d" % (x)
    for y in xrange(repeat + 2):
        print "  x: %d y: %d: Hello, %s" % (x, y, name)
        hello_count += 1
        
print
print "I said hello %d times using the nested loop" % (hello_count)





## Loops can also depend on each other (summing the upper triange of a matrix)
###############################################################################

hello_count = 0
for x in xrange(repeat):
    print "x is now %d" % (x)
    for y in xrange(repeat, x, -1):
        print "  x: %d y: %d: Hello, %s" % (x, y, name)
        hello_count += 1
        
print "\nI said hello %d times using the nested dependent loop" % (hello_count)




###############################################################################
###############################################################################


""" Challenge question: How do I make this:

Mike
   Mike
      Mike
         Mike
            Mike
               Mike
            Mike
         Mike
      Mike
   Mike
Mike
   Mike
      Mike
         Mike
            Mike
               Mike
            Mike
         Mike
      Mike
   Mike
Mike
   Mike
      Mike
         Mike
            Mike
               Mike
            Mike
         Mike
      Mike
   Mike
Mike
   Mike
      Mike
         Mike
            Mike
               Mike
            Mike
         Mike
      Mike
   Mike
Mike
   Mike
      Mike
         Mike
            Mike
               Mike
            Mike
         Mike
      Mike
   Mike

"""
