## URP Bootcamp Exercise 1
################################################################################
## In this exericse, you'll see a few basic operations of assigning variable, 
## printing their values, and basic arthimetic.

## A basic print command
print "Hello, Mike"

## Printing with variables
hi   = "Hello, "
name = "Mike"
print hi + name

## The advantage to variables is their value can be changed
name = "Anne"
print hi + name

## You can also add strings together (concatenate)
message = hi + name
message += " and Kim"
print message

## Notice you have to use str() to convert numbers to strings that can be printed
pi = 3.14159
print "Pi is: " + str(pi)

## its easy to do math in python
radius = 1234.5678
area = pi * (radius ** 2)

## Print the results
print name + ", a circle with a radius of " + str(radius) + " has an area of: " + str(area)

## Easy to ask for a value
radius = float(raw_input("Enter a new radius: "))

## Print the values using 2 decimal places
print "%s, a circle with a radius of %.2f has an area of %.2f " % (name, radius, area)



## Challenge questions: 
###############################################################################
## 1. How would you greet someone in spanish?
## 2. How would you compute the volume of a sphere with this radius?
