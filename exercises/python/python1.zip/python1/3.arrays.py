## URP Bootcamp Exercise 3
################################################################################
## In this exercise you will learn about arrays and conditionals
## An array is a variable that stores multiple items, indexed by a number

## initialize the entire array
data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print "data are: " + str(data)
print "data[0] is: " + str(data[0])
print "data[6] is: " + str(data[6])

## change a value
data[0] = 123
data[6] = 456
print "data are: " + str(data)
print "data[0] is: " + str(data[0])
print "data[6] is: " + str(data[6])

## what does this do?
data[20] = 10

## reset the array
data = []
print "data are: " + str(data)


## Use a for loop to initialize many values of data
################################################################################

## use this to get uniformly random variables with random.randint()
import random

points=300
data = []

## Assing values to the array
for i in xrange(points):
    data.append(random.randint(-1000,1000))

## Now print it back out
print data


## Visualize the data
###############################################################################
import matplotlib.pyplot as plt

## it is not necessary to call figure for the very first plot
plt.figure()

## x-value is just the index (0, 1, 2, ...), y-value is the random val
plt.scatter(range(len(data)), data)

## open a new window
plt.figure()

## make a histogram
plt.hist(data)


## Reset data
data = []
for i in xrange(points):
    data.append(random.randint(-1000,1000) +
                random.randint(-1000,1000) +
                random.randint(-1000,1000))

## any guesses as to what this looks like?
plt.figure()
plt.hist(data)

## lots of cool stuff: http://matplotlib.org/users/pyplot_tutorial.html



## Sort and print the data one element at a time
###############################################################################
data.sort()

print "i\td[i]"
for i in xrange(len(data)):
    d=data[i]
    print "%d\t%d" % (i, d)  
    



## Compute some simple statistics
###############################################################################

## Use this so that you can compute sqrt
import math    

print "There are %d elements in [%d,%d] that sum to %d" % (len(data), min(data), max(data), sum(data))

mean=sum(data)/len(data)

## wait a second!
mean=float(sum(data))/len(data)


sumdiff = 0
for d in data:
    sqdiff = (d - mean) ** 2
    sumdiff += sqdiff   

stdev = math.sqrt(sumdiff / len(data))

print "The mean and standard deviation are: %0.2f +/- %0.2f" % (mean, stdev)




## Count how many elements are lo, medium, or hi values using an if statement
###############################################################################

medium_cutoff = min(data) +   (max(data)-min(data))/3
hi_cutoff     = min(data) + 2*(max(data)-min(data))/3

## store the counts in an array of (low, medium, hi)
bin_counts = [0,0,0]

for i in xrange(len(data)):
    d = data[i]
    if (d < medium_cutoff):
        bin_counts[0] += 1
    elif (d < hi_cutoff):
        bin_counts[1] += 1
    else:
        bin_counts[2] += 1
        
print "There are %d low values >= %d and < %d"  % (bin_counts[0], min(data), medium_cutoff)
print "There are %d med values >= %d and < %d"  % (bin_counts[1], medium_cutoff, hi_cutoff)
print "There are %d high values >= %d and < %d" % (bin_counts[2], hi_cutoff, max(data))




## Challenge questions
###############################################################################

## 1. How else could we find the min or max values?
## 2. How would you compute the average of the lo, medium, or high values?
## 3. How would you divide the counts into quartiles or percentiles?


